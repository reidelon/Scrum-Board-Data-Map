/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.Unirest;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.json.JSONObject;

/**
 *
 * @author reidel.rodriguez
 */
public class JavaApplication1 {

    /**
     * The program does the following, given a date("yyyy-MM-dd") 
     * create a new Sprint and create a task for that sprint, afterwards this updates same task.     
     * the api server is listening in 127.0.0.1:8000
     * change this if need it
     * @author Reidel Lazaro Rodriguez Torres
     * @version 1.0
     * @since 2017-04-10
     */
    public void getQuestionsUsingUnirest() throws Exception {
        String serverName = "http://localhost:";
        String serverPort = "8000";
        //begin-> fetching the root api
        HttpResponse<JsonNode> response = Unirest.get(serverName + serverPort + "/api/").asJson();
        System.out.println("==================================");
        System.out.println("Status " + response.getStatus());
        System.out.println(response.getBody().getObject().toString(2));
        System.out.println("==================================");
        JSONObject api = response.getBody().getObject();
        //end-> fetching the root api

        //begin-> get the token for authorization and set it as a default header
        HttpResponse<JsonNode> jsonResponse = Unirest.post(serverName + serverPort + "/api/token/")
                .field("username", "admin")
                .field("password", "adminadmin")
                .asJson();
        if (jsonResponse.getStatus() == 200) {
            System.out.println(jsonResponse.getBody().getObject().get("token").toString());
            String strinToken = jsonResponse.getBody().getObject().get("token").toString();
            Unirest.setDefaultHeader("Authorization", "Token " + strinToken);
            //end-> get the token for authorization and set it as a default header

            HttpResponse<JsonNode> sprints = Unirest.get(api.get("sprints").toString()).asJson();
            System.out.println("Status code " + sprints.getStatus());
            System.out.println("************************fetching all Sprints*************************");
            System.out.println(sprints.getBody().getArray().toString(2));
            System.out.println("*********************fetching all Sprints****************************");

            System.out.println("*********************Creating a new Sprints****************************");
//            Date dNow = new Date();
//            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
//            Date today = Calendar.getInstance().getTime();
//            String dNow = df.format(today);
//            System.out.println("Report Date: " + dNow);
            BufferedReader br = null;
            br = new BufferedReader(new InputStreamReader(System.in));
            while (true) {
                System.out.print("Enter a date for a neew Sprint(format yyyy-MM-dd) type q to quit: ");
                String input = br.readLine();
                if ("q".equals(input)) {
                    System.out.println("Exit!");
                    System.exit(0);
                }
                System.out.print(input);

                HttpResponse<JsonNode> newsprint = Unirest.post(api.get("sprints").toString())
                        .field("name", "Fast sprint")
                        .field("end", input)
                        .asJson();
                if (newsprint.getStatus() == 201) {
                    System.out.println("Sprint created successfuly");
                    System.out.println(newsprint.getBody().getObject().toString(2));
                    System.out.println("*********************Creating a new Sprints****************************");
//            creating a task for the last created sprint
                    System.out.println("*********************Creating a new Task****************************");
                    HttpResponse<JsonNode> newstask = Unirest.post(api.get("tasks").toString())
                            .field("name", "Something Task")
                            .field("sprint", newsprint.getBody().getObject().getInt("id"))
                            .asJson();
                    if (newstask.getStatus() == 201) {
                        System.out.println("Task created successfuly");
                        System.out.println(newstask.getBody().getObject().toString(2));
                        System.out.println("*********************Creating a new Task****************************");
                        System.out.println("*********************Update a new Task****************************");
                        newstask.getBody().getObject().put("assigned", "admin");
                        newstask.getBody().getObject().put("status", "2");
                        DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                        Date today = Calendar.getInstance().getTime();
                        String dNow = df.format(today);
                        System.out.println("Report Date: " + dNow);
                        newstask.getBody().getObject().put("started", dNow);
                        HttpResponse<JsonNode> updatedTask = Unirest.put(newstask.getBody().getObject().getJSONObject("links").get("self").toString())
                                .header("accept", "application/json")
                                .header("Content-Type", "application/json")
                                .body(newstask.getBody())
                                .asJson();
                        if (updatedTask.getStatus() == 200) {
                            System.out.println("Task updated successfuly");
                            System.out.println(updatedTask.getBody().getObject().toString(2));
                            System.out.println("*********************Update a new Task****************************");
                        } else {
                            badOperation(updatedTask);
                        }
                        System.out.println("*********************Update a new Task****************************");
                    } else {
                        badOperation(newstask);
                    }
                } else {
                    badOperation(newsprint);
                }
            }
        } else {
            badOperation(jsonResponse);
        }
    }

    private void badOperation(HttpResponse<JsonNode> response) {
        System.out.println("Status code " + response.getStatus() + " " + response.getStatusText());
        System.out.println("Cause " + response.getBody().getObject().toString());
    }

    public static void main(String args[]) throws Exception {
        JavaApplication1 client = new JavaApplication1();
        client.getQuestionsUsingUnirest();
        Unirest.shutdown();
//        System.out.println("******************************");
//        HashMap<String, String> hmap = new HashMap<String, String>();
//        hmap.put("12", "Chaitanya");
//        hmap.put("2", "Rahul");
//        hmap.put("7", "Singh");
//        hmap.put("49", "Ajeet");
//        hmap.put("3", "Anuj");
//        String var = hmap.get("2");
//        System.out.println("Value at index 2 is: " + var);
    }

}
