/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.JsonNode;
import com.mashape.unirest.http.ObjectMapper;
import com.mashape.unirest.http.Unirest;
import java.util.HashMap;
import org.json.JSONObject;
import java.util.Date;

/**
 *
 * @author reidel.rodriguez
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    public void getQuestionsUsingUnirest() throws Exception {
        //begin-> fetching the root api
        HttpResponse<JsonNode> response = Unirest.get("http://localhost:8000/api/").asJson();
        System.out.println("==================================");
        System.out.println("Status " + response.getStatus());
        System.out.println(response.getBody().getObject().toString(2));
        System.out.println("==================================");
        JSONObject api = response.getBody().getObject();
        //end-> fetching the root api

        //begin-> get the token for authorization and set it as a default header
        HttpResponse<JsonNode> jsonResponse = Unirest.post("http://localhost:8000/api/token/")
                .field("username", "admin")
                .field("password", "adminadmin")
                .asJson();
        if (jsonResponse.getStatus() == 200) {
            System.out.println(jsonResponse.getBody().getObject().get("token").toString());
            String strinToken = jsonResponse.getBody().getObject().get("token").toString();
            Unirest.setDefaultHeader("Authorization", "Token " + strinToken);
            //end-> get the token for authorization and set it as a default header

            HttpResponse<JsonNode> sprints = Unirest.get(api.get("sprints").toString()).asJson();
            System.out.println("Status code " + sprints.getStatus());
            System.out.println("************************fetching all Sprints*************************");
            System.out.println(sprints.getBody().getArray().toString(2));
            System.out.println("*********************fetching all Sprints****************************");

            System.out.println("*********************Creating a new Sprints****************************");
            Date dNow = new Date();
            HttpResponse<JsonNode> newsprint = Unirest.post(api.get("sprints").toString())
                    .field("name", "Fast sprint")
                    .field("end", "2017-4-1")
                    .asJson();
            if (newsprint.getStatus() == 201) {
                System.out.println("Sprint created successfuly");
                System.out.println(newsprint.getBody().getObject().toString(2));
                System.out.println("*********************Creating a new Sprints****************************");
//            creating a task for the last crated sprint
                System.out.println("*********************Creating a new Task****************************");
                HttpResponse<JsonNode> newstask = Unirest.post(api.get("tasks").toString())
                        .field("name", "Something Task")
                        .field("sprint", newsprint.getBody().getObject().getInt("id"))
                        .asJson();
                if (newstask.getStatus() == 201) {
                    System.out.println("Task created successfuly");
                    System.out.println(newstask.getBody().getObject().toString(2));
                    System.out.println("*********************Creating a new Task****************************");
                    System.out.println("*********************Update a new Task****************************");
                    newstask.getBody().getObject().put("assigned", "admin");
                    newstask.getBody().getObject().put("status", "2");
                    newstask.getBody().getObject().put("started", "2017-4-4");
                    HttpResponse<JsonNode> updatedTask = Unirest.put(newstask.getBody().getObject().getJSONObject("links").get("self").toString())
                            .header("accept", "application/json")
                            .header("Content-Type", "application/json")
                            .body(newstask.getBody())
                            .asJson();
                    if (updatedTask.getStatus() == 200) {
                        System.out.println("Task updated successfuly");
                        System.out.println(updatedTask.getBody().getObject().toString(2));
                        System.out.println("*********************Update a new Task****************************");
                    } else {
                        badOperation(updatedTask);
                    }
                    System.out.println("*********************Update a new Task****************************");
                } else {
                    badOperation(newstask);
                }
            } else {
                badOperation(newsprint);
            }

        } else {
            badOperation(jsonResponse);
        }
    }

    private void badOperation(HttpResponse<JsonNode> response) {
        System.out.println("Status code " + response.getStatus() + " " + response.getStatusText());
        System.out.println("Cause " + response.getBody().getObject().toString());
    }

    public static void main(String args[]) throws Exception {
        JavaApplication1 client = new JavaApplication1();
        client.getQuestionsUsingUnirest();
        Unirest.shutdown();
//        System.out.println("******************************");
//        HashMap<String, String> hmap = new HashMap<String, String>();
//        hmap.put("12", "Chaitanya");
//        hmap.put("2", "Rahul");
//        hmap.put("7", "Singh");
//        hmap.put("49", "Ajeet");
//        hmap.put("3", "Anuj");
//        String var = hmap.get("2");
//        System.out.println("Value at index 2 is: " + var);
    }

}
